def build_report(
        total_revenue,
        revenue_by_category,
        revenue_by_channel,
        oversold,
        low_stock,
        unknown_skus
):

    return {

        "total_revenue": total_revenue,

        "revenue_by_category": revenue_by_category,

        "revenue_by_channel": revenue_by_channel,

        "oversold_skus": list(oversold),

        "low_stock_skus": list(low_stock),

        "unknown_skus": list(unknown_skus)
    }