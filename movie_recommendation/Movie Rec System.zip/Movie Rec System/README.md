# CineMatch — Full Movie Recommendation Project

This project extends the existing TMDB 5000 movie recommendation notebook into a full-stack Netflix-style application.

## Stack
- FastAPI backend
- Pandas + scikit-learn content-based recommender
- TMDB API for live movie metadata/posters
- HTML/CSS/JavaScript frontend

## Run
1. Create a virtual environment.
2. Install `requirements.txt`.
3. Copy `.env.example` to `.env` and add your TMDB API key.
4. Run `python -m uvicorn backend.main:app --reload`.
5. Open http://127.0.0.1:8000
