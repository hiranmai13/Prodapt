const API = '/api';
const IMG = 'https://image.tmdb.org/t/p/w500';
const BACKDROP = 'https://image.tmdb.org/t/p/original';

const $ = id => document.getElementById(id);

function card(movie) {
  const poster = movie.poster_path ? IMG + movie.poster_path : 'https://via.placeholder.com/340x510?text=No+Poster';
  const rating = movie.vote_average ? `★ ${Number(movie.vote_average).toFixed(1)}` : '';
  return `<article class="card" data-id="${movie.id}"><img class="poster" src="${poster}" loading="lazy"><div class="card-title">${escapeHtml(movie.title || '')}</div><div class="meta">${rating}</div></article>`;
}

function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}

function renderRow(id, movies){
  $(id).innerHTML = movies.map(card).join('');
  $(id).querySelectorAll('.card').forEach(el => el.onclick = () => openMovie(el.dataset.id));
}

async function getJson(url){const r=await fetch(url);if(!r.ok) throw new Error(await r.text());return r.json();}

async function loadLists(){
  const configs=[['popularRow','popular'],['nowRow','now-playing'],['topRow','top-rated'],['upcomingRow','upcoming']];
  for(const [id,kind] of configs){try{const d=await getJson(`${API}/list/${kind}`);renderRow(id,d.results)}catch(e){$(id).innerHTML='<p>Could not load movies. Check your API key.</p>';}}
}

async function loadHero(){
  try{const d=await getJson(`${API}/list/popular`);const m=d.results[0];
    $('heroTitle').textContent=m.title;$('heroOverview').textContent=m.overview;
    $('hero').style.backgroundImage=`linear-gradient(90deg,rgba(0,0,0,.95),rgba(0,0,0,.35),rgba(0,0,0,.2)),linear-gradient(0deg,#080808,transparent 45%),url(${BACKDROP+m.backdrop_path})`;
    $('heroButton').onclick=()=>openMovie(m.id);
  }catch(e){$('heroTitle').textContent='CineMatch';}
}

async function openMovie(id){
  $('modal').classList.remove('hidden');$('modalContent').innerHTML='<div class="detail-body"><p>Loading...</p></div>';
  try{
    const [movie, rec] = await Promise.all([getJson(`${API}/movies/${id}`), getJson(`${API}/movies/${id}/recommendations?limit=12`)]);
    const backdrop=movie.backdrop_path?`style="background-image:url(${BACKDROP+movie.backdrop_path})"`:'';
    const poster=movie.poster_path?IMG+movie.poster_path:'';
    const genres=(movie.genres||[]).map(x=>x.name).join(' • ');
    const recommendationsWithPosters=await Promise.all(rec.results.slice(0,8).map(async x=>{try{const d=await getJson(`${API}/movies/${x.id}`);return {...x,poster_path:d.poster_path,vote_average:d.vote_average}}catch{return x}}));
    $('modalContent').innerHTML=`<div class="detail-backdrop" ${backdrop}></div><div class="detail-body"><img src="${poster}" style="width:120px;border-radius:5px;float:left;margin:0 20px 10px 0"><h2>${escapeHtml(movie.title)}</h2><p>${escapeHtml(genres)}</p><p>${escapeHtml(movie.overview||'No overview available.')}</p><p>⭐ ${Number(movie.vote_average||0).toFixed(1)} &nbsp; ${movie.release_date||''}</p><h3>You may also like</h3><div class="rec-row">${recommendationsWithPosters.map(card).join('')}</div><div style="clear:both"></div></div>`;
    $('modalContent').querySelectorAll('.card').forEach(el=>el.onclick=()=>openMovie(el.dataset.id));
  }catch(e){$('modalContent').innerHTML=`<div class="detail-body"><p>${escapeHtml(e.message)}</p></div>`;}
}

$('closeModal').onclick=()=> $('modal').classList.add('hidden');
$('modal').onclick=e=>{if(e.target.id==='modal')$('modal').classList.add('hidden')};
$('searchForm').onsubmit=async e=>{e.preventDefault();const q=$('searchInput').value.trim();if(!q)return;try{const d=await getJson(`${API}/search?q=${encodeURIComponent(q)}`);$('searchSection').classList.remove('hidden');renderRow('searchRow',d.results);$('searchSection').scrollIntoView({behavior:'smooth'});}catch(err){alert(err.message)}};
loadHero();loadLists();
