import os
from typing import Any

import requests
from dotenv import load_dotenv

load_dotenv()

TMDB_BASE_URL = "https://api.themoviedb.org/3"
TMDB_API_KEY = os.getenv("TMDB_API_KEY", "").strip()


def _get(path: str, params: dict[str, Any] | None = None):
    if not TMDB_API_KEY:
        raise RuntimeError("TMDB_API_KEY is missing. Add it to .env")
    params = params or {}
    params["api_key"] = TMDB_API_KEY
    params.setdefault("language", "en-US")
    response = requests.get(f"{TMDB_BASE_URL}{path}", params=params, timeout=15)
    response.raise_for_status()
    return response.json()


def list_movies(kind: str):
    paths = {
        "popular": "/movie/popular",
        "top-rated": "/movie/top_rated",
        "now-playing": "/movie/now_playing",
        "upcoming": "/movie/upcoming",
    }
    return _get(paths[kind], {"page": 1})


def search_movies(query: str):
    return _get("/search/movie", {"query": query, "page": 1, "include_adult": "false"})


def movie_details(movie_id: int):
    return _get(f"/movie/{movie_id}", {"append_to_response": "credits,videos"})
