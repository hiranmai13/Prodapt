import ast
from pathlib import Path

import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.metrics.pairwise import cosine_similarity


# ============================================================
# PATHS
# ============================================================

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "Data"

MOVIES_PATH = DATA_DIR / "tmdb_5000_movies.csv"
CREDITS_PATH = DATA_DIR / "tmdb_5000_credits.csv"


# ============================================================
# HELPER FUNCTIONS
# ============================================================

def safe_literal_eval(value):
    """
    Convert JSON-like string data from the CSV into Python objects.
    """
    if pd.isna(value):
        return []

    try:
        return ast.literal_eval(value)
    except (ValueError, SyntaxError):
        return []


def parse_names(value):
    """
    Extract names from fields such as:
    genres, keywords, cast, etc.
    """
    data = safe_literal_eval(value)

    if not isinstance(data, list):
        return []

    return [
        str(item.get("name", "")).replace(" ", "").lower()
        for item in data
        if isinstance(item, dict) and item.get("name")
    ]


def parse_cast(value):
    """
    Get the top 3 cast members.
    """
    data = safe_literal_eval(value)

    if not isinstance(data, list):
        return []

    return [
        str(item.get("name", "")).replace(" ", "").lower()
        for item in data[:3]
        if isinstance(item, dict) and item.get("name")
    ]


def parse_director(value):
    """
    Extract director from the crew.
    """
    data = safe_literal_eval(value)

    if not isinstance(data, list):
        return []

    for item in data:
        if (
            isinstance(item, dict)
            and item.get("job") == "Director"
            and item.get("name")
        ):
            return [str(item["name"]).replace(" ", "").lower()]

    return []


# ============================================================
# BUILD RECOMMENDATION MODEL
# ============================================================

def build_model():

    print("Loading movie datasets...")

    movies = pd.read_csv(MOVIES_PATH)
    credits = pd.read_csv(CREDITS_PATH)

    print(f"Movies dataset: {movies.shape}")
    print(f"Credits dataset: {credits.shape}")

    # --------------------------------------------------------
    # Rename movie_id -> id
    # --------------------------------------------------------

    credits = credits.rename(columns={"movie_id": "id"})

    # --------------------------------------------------------
    # Merge datasets
    # --------------------------------------------------------

    df = movies.merge(
        credits,
        on="id",
        how="inner"
    )

    print(f"Merged dataset: {df.shape}")

    # --------------------------------------------------------
    # Fill missing overview
    # --------------------------------------------------------

    df["overview"] = df["overview"].fillna("").astype(str)

    # --------------------------------------------------------
    # Extract useful information
    # --------------------------------------------------------

    df["genres"] = df["genres"].apply(parse_names)

    df["keywords"] = df["keywords"].apply(parse_names)

    df["cast"] = df["cast"].apply(parse_cast)

    df["crew"] = df["crew"].apply(parse_director)

    # --------------------------------------------------------
    # Convert overview into words
    # --------------------------------------------------------

    df["overview_tokens"] = (
        df["overview"]
        .str.lower()
        .str.split()
    )

    # --------------------------------------------------------
    # Create tags
    # --------------------------------------------------------

    def create_tags(row):

        overview_words = row["overview_tokens"]

        if not isinstance(overview_words, list):
            overview_words = []

        genres = row["genres"]
        keywords = row["keywords"]
        cast = row["cast"]
        crew = row["crew"]

        all_words = (
            overview_words
            + genres
            + keywords
            + cast
            + crew
        )

        return " ".join(
            str(word)
            for word in all_words
            if word
        )

    df["tags"] = df.apply(create_tags, axis=1)

    # --------------------------------------------------------
    # IMPORTANT: Make sure tags are valid strings
    # --------------------------------------------------------

    df["tags"] = (
        df["tags"]
        .fillna("")
        .astype(str)
        .str.strip()
    )

    print("Sample tags:")
    print(df["tags"].head(3).to_list())

    print(
        "Movies with tags:",
        (df["tags"].str.len() > 0).sum()
    )

    # --------------------------------------------------------
    # Count Vectorizer
    # --------------------------------------------------------

    vectorizer = CountVectorizer(
        max_features=5000,
        stop_words="english"
    )

    vectors = vectorizer.fit_transform(df["tags"])

    print("Vector shape:", vectors.shape)

    # --------------------------------------------------------
    # Cosine similarity
    # --------------------------------------------------------

    similarity = cosine_similarity(vectors)

    # --------------------------------------------------------
    # Create movie ID -> dataframe index mapping
    # --------------------------------------------------------

    index_by_id = pd.Series(
        df.index,
        index=df["id"]
    ).to_dict()

    print("Recommendation model built successfully!")

    return df, similarity, index_by_id


# ============================================================
# BUILD MODEL WHEN SERVER STARTS
# ============================================================

movies_df, similarity_matrix, index_by_id = build_model()


# ============================================================
# RECOMMENDATION FUNCTION
# ============================================================

def recommendations(movie_id, limit=12):

    try:
        movie_id = int(movie_id)
    except (ValueError, TypeError):
        return []

    if movie_id not in index_by_id:
        return []

    movie_index = index_by_id[movie_id]

    similarity_scores = list(
        enumerate(similarity_matrix[movie_index])
    )

    similarity_scores = sorted(
        similarity_scores,
        key=lambda x: x[1],
        reverse=True
    )

    results = []

    for index, score in similarity_scores:

        # Skip the movie itself
        if index == movie_index:
            continue

        movie = movies_df.iloc[index]

        results.append(
            {
                "id": int(movie["id"]),
                "title": str(movie["title"]),
                "overview": str(movie["overview"]),
                "score": round(float(score), 4),
            }
        )

        if len(results) >= limit:
            break

    return results