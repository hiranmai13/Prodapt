from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from .recommender import recommendations, movies_df
from .tmdb import list_movies, search_movies, movie_details

app = FastAPI(title="CineMatch Movie Recommendation API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ROOT = __import__("pathlib").Path(__file__).resolve().parents[1]
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")


def normalize_tmdb(items):
    result = []
    for x in items:
        if not x.get("poster_path"):
            continue
        result.append({
            "id": x.get("id"),
            "title": x.get("title") or x.get("name"),
            "overview": x.get("overview") or "",
            "poster_path": x.get("poster_path"),
            "backdrop_path": x.get("backdrop_path"),
            "vote_average": x.get("vote_average", 0),
            "release_date": x.get("release_date", ""),
        })
    return result


@app.get("/api/health")
def health():
    return {"status": "ok", "movies_loaded": len(movies_df)}


@app.get("/api/movies/{movie_id}/recommendations")
def get_recommendations(movie_id: int, limit: int = Query(12, ge=1, le=30)):
    recs = recommendations(movie_id, limit)
    if not recs:
        raise HTTPException(status_code=404, detail="Movie not found in local recommendation dataset")
    return {"results": recs}


@app.get("/api/movies/{movie_id}")
def get_movie(movie_id: int):
    try:
        return movie_details(movie_id)
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get("/api/search")
def search(q: str = Query(..., min_length=1)):
    try:
        data = search_movies(q)
        return {"results": normalize_tmdb(data.get("results", []))}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get("/api/list/{kind}")
def movie_list(kind: str):
    if kind not in {"popular", "top-rated", "now-playing", "upcoming"}:
        raise HTTPException(status_code=400, detail="Invalid movie list")
    try:
        data = list_movies(kind)
        return {"results": normalize_tmdb(data.get("results", []))}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)) from exc


@app.get("/")
def home():
    return FileResponse("static/index.html")
